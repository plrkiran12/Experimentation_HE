#pragma once
#include "openfhe.h"

using namespace lbcrypto;

CryptoContext<DCRTPoly> SetupCKKSContext();
